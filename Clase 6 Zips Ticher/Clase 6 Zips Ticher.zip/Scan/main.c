#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x;
    int cant;

    return 0;
}
