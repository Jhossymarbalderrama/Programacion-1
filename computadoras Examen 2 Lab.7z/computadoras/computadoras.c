#include <stdio.h>
#include <stdlib.h>
#include <string.h>
//#include "bicicleta.h"
#include "computadoras.h"
#include "LinkedList.h"
#include "controller.h"

eComputer* computadora_new(){
    eComputer* nuevo = (eComputer*) malloc( sizeof(eComputer));
    if(nuevo != NULL)
    {
        nuevo->id = 0;
        strcpy(nuevo->descripcion," ");
        nuevo->precio = 0;
        nuevo->idTipo = 0;
        strcpy(nuevo->oferta," ");
    }
    return nuevo;
}

eComputer* computadora_newParametros(char* idStr, char*descripStr, char* precioStr, char* idTipoStr){
    eComputer* nuevo = computadora_new();

    int id;
    int precio;
    int idTipo;

    id = atoi(idStr);
    precio = atoi(precioStr);
    idTipo = atoi(idTipoStr);


    if( nuevo != NULL)
    {
    printf("Entro");
        if(
            computadora_setId(nuevo,id) &&
            computadora_setDescrip(nuevo,descripStr) &&
            computadora_setPrecio(nuevo,precio) &&
            computadora_setIdTipo(nuevo,idTipo) &&
            computadora_setOferta(nuevo))
        {
            // printf("Empleado creado correctamente\n");
        }
        else
        {
            nuevo = NULL;
        }
    }

    return nuevo;


}

int computadora_setId(eComputer* this,int id){
    int todoOk = 0;
    if(this != NULL && id >= 0)
    {
        this->id = id;
        todoOk = 1;
    }
    return todoOk;
}


int computadora_setDescrip(eComputer* this,char* descrip){
    int todoOk = 0;
    if( this != NULL && descrip != NULL)
    {
        strcpy(this->descripcion, descrip);
        todoOk = 1;
    }
    return todoOk;
}

int computadora_setPrecio(eComputer* this,int precio){
    int todoOk = 0;
    if(this != NULL && precio >= 0)
    {
        this->precio = precio;
        todoOk = 1;
    }
    return todoOk;
}

int computadora_setIdTipo(eComputer* this,int idTipo){
    int todoOk = 0;
    if(this != NULL && idTipo >= 0)
    {
        this->idTipo = idTipo;
        todoOk = 1;
    }
    return todoOk;
}

int computadora_setOferta(eComputer* this){
    int todoOk = 0;

    if( this != NULL)
    {
        strcpy(this->oferta, " ");
        todoOk = 1;
    }
    return todoOk;
}


int mostrarComputadora(eComputer* e)
{
    int todoOk = 0;
    int id;
    char descripcion[60];
    int precio = 0;
    int idtipo = 0;
    char oferta[30];


    if( e != NULL)
    {
        computadora_getId(e,&id);
        computadora_getDescrip(e,descripcion);
        computadora_getPrecio(e,&precio);
        computadora_getIdTipo(e,&idtipo);
        computadora_getDescrip(e,oferta);

        //printf("%4d      %10s       %10s     %2d \n",id,nombre,tipo,tiempo);
        printf("ID :%4d         DESCRIP:%s              PRECIO:%d            TIPO:%d          OFERTA%s \n\n",id,descripcion,precio,idtipo,oferta);
        todoOk = 1;
    }

    return todoOk;
}

int listarComputadoras(LinkedList* lista){
    int todoOk = 0;
    eComputer* aux;
    int flag = 0;
    if(lista != NULL)
    {

        printf("  id     descripcion    precio  idTipo  oferta\n\n");
        for( int i=0; i < ll_len(lista); i++)
        {
            aux = (eComputer*) ll_get(lista,i);
            mostrarComputadora(aux);
            flag = 1;
        }
        if(flag == 0){
            printf("No hay datos\n");
        }

        todoOk = 1;
    }
    return todoOk;
}

int computadora_getId(eComputer* this,int* id){
    int todoOk = 0;

    if( this != NULL && id != NULL)
    {
        *id = this->id;
        todoOk = 1;
    }
    return todoOk;
}

int computadora_getDescrip(eComputer* this,char* descrip){
    int todoOk = 0;

    if( this != NULL && descrip != NULL)
    {
        strcpy(descrip, this->descripcion);
        todoOk = 1;
    }
    return todoOk;
}

int computadora_getPrecio(eComputer* this,int* precio){
    int todoOk = 0;

    if( this != NULL && precio != NULL)
    {
        *precio = this->precio;
        todoOk = 1;
    }
    return todoOk;
}

int computadora_getIdTipo(eComputer* this,int* idTipo){
    int todoOk = 0;

    if( this != NULL && idTipo != NULL)
    {
        *idTipo = this->idTipo;
        todoOk = 1;
    }
    return todoOk;
}

int computadora_getOferta(eComputer* this,char* oferta){
    int todoOk = 0;

    if( this != NULL && oferta != NULL)
    {
        strcpy(oferta, this->oferta);
        todoOk = 1;
    }
    return todoOk;
}

/**
int bicicleta_getId(eBicicleta* this,int* id){
    int todoOk = 0;

    if( this != NULL && id != NULL)
    {
        *id = this->id_bike;
        todoOk = 1;
    }
    return todoOk;
}

int bicicleta_getNombre(eBicicleta* this,char* nombre){
    int todoOk = 0;

    if( this != NULL && nombre != NULL)
    {
        strcpy(nombre, this->nombre);
        todoOk = 1;
    }
    return todoOk;
}

int bicicleta_getTipo(eBicicleta* this,char* tipo){
    int todoOk = 0;

    if( this != NULL && tipo != NULL)
    {
        strcpy(tipo, this->tipo);
        todoOk = 1;
    }
    return todoOk;
}


int bicicleta_getTiempo(eBicicleta* this,int* tiempo){
    int todoOk = 0;

    if( this != NULL && tiempo != NULL)
    {
        *tiempo = this->tiempo;
        todoOk = 1;
    }
    return todoOk;
}

*/
