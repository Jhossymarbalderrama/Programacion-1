#include <stdio.h>
#include <stdlib.h>

int menu(void){

    int opcion;

    printf("-------       Menu De Inicio      -------\n\n");
    printf("1. Cargar archivo.\n");
    printf("2. Ordenar lista por Tipo.\n");
    printf("3. Imprimir Lista.\n");
    printf("4. Asignar Oferta.\n");
    printf("5. Generar Lista solo Desktop.\n");
    printf("6. Salir\n\n");
    printf("Ingrese opcion: ");
    scanf("%d",&opcion);

    return opcion;
}
