#include "LinkedList.h"
#ifndef COMPUTADORAS_H_INCLUDED
#define COMPUTADORAS_H_INCLUDED
typedef struct{
    int id;
    char descripcion[100];
    int precio;
    int idTipo;
    char oferta[30];
}eComputer;
#endif // COMPUTADORAS_H_INCLUDED

eComputer* computadora_newParametros(char* idStr, char*descripStr, char* precioStr, char* idTipoStr);
eComputer* computadora_new();

int computadora_setId(eComputer* this,int id);
int computadora_setDescrip(eComputer* this,char* descrip);
int computadora_setPrecio(eComputer* this,int precio);
int computadora_setIdTipo(eComputer* this,int idTipo);
int computadora_setOferta(eComputer* this);

int computadora_getId(eComputer* this,int* id);
int computadora_getDescrip(eComputer* this,char* descrip);
int computadora_getPrecio(eComputer* this,int* precio);
int computadora_getIdTipo(eComputer* this,int* idTipo);
int computadora_getOferta(eComputer* this,char* oferta);

int mostrarComputadora(eComputer* e);
int listarComputadoras(LinkedList* lista);
