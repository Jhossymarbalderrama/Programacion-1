#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "LinkedList.h"
#include "bicicleta.h"
#include "controller.h"

int cargarArchivo(LinkedList* lista, char* path){

    int todoOk = 0;
    FILE* f;
    char buffer[4][100];
    int cant;
    eBicicleta* aux = NULL;


    if(lista != NULL && path != NULL){

        f = fopen(path, "r");

        if( f == NULL)
        {
            printf("No se pudo abrir el archivo\n");
            return todoOk;
        }

    fscanf(f,"%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2],buffer[3]);
        while(!feof(f))
        {
            cant = fscanf(f,"%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2],buffer[3]);

        if(cant == 4){
            aux = bicicleta_newParametros(buffer[0],buffer[1],buffer[2],buffer[3]);
            if( aux != NULL)
                {
                    ll_add(lista,aux);

                }
            }
            else
            {
                break;
            }
        }

        todoOk = 1;


    }
    return todoOk;
}
/*
int filtroMenores(void* elemento){

    int todoOk = 0;

    eCachorro* cach;
    cach = (eCachorro*)elemento;
    int dias;
    cachorro_getDias(cach,&dias);

    if(dias >= 45){
        todoOk = 1;
    }
    return todoOk;
}
*/
/** guardar en text*/
int controller_saveAsText(char* path, LinkedList* e)
{

    int todoOk = 0;
    int cant;
    FILE* f;
    eBicicleta* aux = NULL;


    if(e!= NULL && path != NULL){

        f = fopen(path,"w");
        if(f == NULL){
            return todoOk;
        }

        fprintf(f,"id_bike,nombre,tipo,tiempo\n");
        for(int i = 0; i < ll_len(e); i++){
            aux = ll_get(e,i);

            cant = fprintf(f,"%2d  %10s %5s %2d\n",aux->id_bike,aux->nombre,aux->tipo,aux->tiempo);
            if(cant < 1){
                return todoOk;
            }
        }
        fclose(f);
        todoOk = 1;
    }
    return todoOk;
}


int asignarTiempo(LinkedList* lista){
    int todoOk = 0;
    int ban = 0;

    ban = ll_map(lista,setTiempo);

    if(ban == 1){
        printf("Se pudo el mapp\n");
        todoOk  =1 ;
    }else{
        printf("No se pudo el mapp\n");
    }
    return todoOk;
}




/*
int filtroCallejeros(void* elemento){

    int todoOk = 0;
    eCachorro* cach;
    cach = (eCachorro*)elemento;
    char raza[20];
    cachorro_getRaza(cach,raza);
    //char a[20] = "Callejeros";

    if(strcmp(raza,"Callejero") == 0){
        todoOk = 1;
    }
    return todoOk;
}
*/

int setTiempo(void){
    //srand (time(NULL));
    int aleatorio;
    aleatorio = rand()%(71)+50;
}






int filtroTipo(void* elemento){

    int todoOk = 0;
    int entro = 0;
    char filtro[10];

    eBicicleta* tipo;

    if(entro == 0){
        printf("Por que tipo desea filtrar: ");
        fflush(stdin);
        gets(filtro);
        entro = 1;
    }

    tipo = (eBicicleta*)elemento;
    char tip;
    bicicleta_getTipo(tipo,&tip);

    if(tip != filtro){
        todoOk = 1;
    }
    return todoOk;
}

int archivosFiltroTipo(LinkedList* lista){

    int todoOk = 0;

    LinkedList* lista2 = ll_newLinkedList();

    lista2 = ll_filter(lista,filtroTipo);

    if(controller_saveAsText("FiltroXTipo.csv",lista2)){
        todoOk = 1;
    }

        return todoOk;
}
