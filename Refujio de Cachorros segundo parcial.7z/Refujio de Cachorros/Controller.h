int controller_loadFromText(char* path, LinkedList* ArrayListCachorros);
int controller_ListCachorros(LinkedList* ArrayListCachorros);
