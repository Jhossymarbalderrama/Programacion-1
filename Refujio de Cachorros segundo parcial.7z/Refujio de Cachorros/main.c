#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "cachorros.h"
#include <conio.h>
#include <string.h>

int menu();

int main()
{
    char rta = 'n';
    LinkedList* listaCachorros = ll_newLinkedList();
    LinkedList* listaCachorros2 = NULL;
    listaCachorros2 = ll_newLinkedList();
    int flag = 0;
    char archivo[20];
    char extension[5] = ".csv";
    int listar = 0;

    if( listaCachorros == NULL)
    {
        printf("No se pudo asignar memoria\n");
        system("pause");
        exit(EXIT_FAILURE);
    }

    do
    {
        switch(menu())
        {
        case 1:
            if(flag == 0)
            {
                printf("Ingrese el Nombre del Archivo: ");
                fflush(stdin);
                gets(archivo);

                strcat(archivo,extension);

                    if(controller_loadFromText(archivo,listaCachorros))
                    {
                        printf("Cachorros cargados con exito\n");
                         flag = 1;
                    }
            }
            else
            {
                printf("Los Cachorros ya han sido cargados.\n");
            }
            break;
        case 2:
                        if(flag)
            {
                controller_ListCachorros(listaCachorros);
            }
            else
            {
                printf("No hay Cachorros cargados desde un archivo.\n");
            }
            break;
        case 3:
            if(flag)
            {
                listaCachorros2 = filtroMenores45Dias(listaCachorros);
                printf("Lista clonada con exito.\n");
                printf("Desea Listar las 2 Listas ? (1 Si / 0 No): ");
                scanf("%d",&listar);
                if(listar)
                {
                    printf("\n        ----------  LISTA CLON  ----------\n");
                    controller_ListCachorros(listaCachorros2);
                    printf("\n        ----------  LISTA ORIGINAL  ----------\n");
                    controller_ListCachorros(listaCachorros);
                }
            }
            break;
            filtroMenores45Dias(listaCachorros);
            break;
        case 4:
            filtroMachos(listaCachorros);
            break;
        case 5:

            break;
        case 6:
            printf("Confirma salir?: (S/N) ");
            fflush(stdin);
            rta = getche();
            printf("\n\n");
            break;
        }
        if(rta != 's')
        {
            system("pause");
            system("cls");
        }

    }
    while(rta == 'n');
    return 0;
}

/** \brief  Menu Principal de Opciones
 * \param
 * \return int Opcion
 */
int menu()
{
    int opcion;

    printf("-------     Menu De Inicio     -------\n\n");
    printf("1. Cargar los datos de los Cachorros desde el archivo data.csv (modo texto).\n");
    printf("2. Listar Cachorros.\n");
    printf("3. Filtrar menores de 45 dias.\n");
    printf("4. Filtrar Machos.\n");
    printf("5. Generar listado de Callejeros.\n");
    printf("6. Salir.\n\n");
    printf("Ingrese opcion: ");
    scanf("%d",&opcion);

    return opcion;
}
