#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "Controller.h"
#include "cachorros.h"
#include <string.h>


int mostrarCachorro(Cachorros* e)
{
    int todoOk = 0;

    if( e != NULL)
    {
        printf("%4d     %10s     %4d    %10s    %2s     %1s \n",e->id_Cachorro,e->nombre,e->dias,e->raza,e->reservado,e->genero);
        todoOk = 1;

    }

    return todoOk;
}

Cachorros* cachorros_new()
{
    Cachorros* nuevo = (Cachorros*) malloc( sizeof(Cachorros));
    if(nuevo != NULL)
    {
        nuevo->id_Cachorro = 0;
        strcpy(nuevo->nombre, " ");
        nuevo->dias = 0;
        strcpy(nuevo->raza, " ");
        strcpy(nuevo->reservado, " ");
        strcpy(nuevo->genero, " ");
    }
    return nuevo;
}


Cachorros* cachorros_newParametros(char* idStr,char* nombreStr,char* diasStr,char* razaStr,char* reservadoStr,char* generoStr)
{
    Cachorros* nuevo = cachorros_new();

    int id;
    int dias;
    id = atoi(idStr);
    dias = atoi(diasStr);

    if( nuevo != NULL)
    {
        if(cachorro_setId(nuevo, id) &&
                cachorro_setNombre(nuevo, nombreStr)&&

                cachorro_setDias(nuevo,dias) &&
                cachorro_setRaza(nuevo, razaStr)&&
                cachorro_setReservado(nuevo, reservadoStr)&&
                cachorro_setgenero(nuevo, generoStr))
        {
            // printf("cachorros creado correctamente\n");
        }
        else
        {
            nuevo = NULL;
        }
    }

    return nuevo;
}



/** \brief Seteo ID
 * \param   Cachorros* this,int id
 * \return int todoOk
 */

int cachorro_setId(Cachorros* this,int id)
{

    int todoOk = 0;
    if(this != NULL && id >= 0)
    {
        this->id_Cachorro = id;
        todoOk = 1;
    }
    return todoOk;
}

/** \brief Seteo Nombre
 * \param   Cachorros* this,char* nombre
 * \return int todoOk
 */
int cachorro_setNombre(Cachorros* this,char* nombre)
{
    int todoOk = 0;
    if( this != NULL && nombre != NULL && strlen(nombre) < 128)
    {
        strcpy(this->nombre, nombre);
        todoOk = 1;
    }
    return todoOk;
}

int cachorro_setDias(Cachorros* this,int dias){
    int todoOk = 0;
    if(this != NULL && dias > 0)
    {
       this->dias = dias;
        todoOk = 1;
    }
    return todoOk;
}
int cachorro_setRaza(Cachorros* this,char* raza){
    int todoOk = 0;
    if( this != NULL && raza != NULL && strlen(raza) < 128)
    {
        strcpy(this->raza, raza);
        todoOk = 1;
    }
    return todoOk;
}
int cachorro_setReservado(Cachorros* this,char* reservado){
    int todoOk = 0;
    if( this != NULL && reservado != NULL && strlen(reservado) == 2)
    {
        if(strlen(reservado) == 2){
        strcpy(this->reservado, reservado);
        todoOk = 1;
        }
    }
    return todoOk;
}
int cachorro_setgenero(Cachorros* this,char* genero){
    int todoOk = 0;
    if( this != NULL && genero != NULL && strlen(genero) < 6)
    {
        strcpy(this->genero, genero);
        todoOk = 1;
    }
    return todoOk;
}

/** \brief Obtengo Nombre
 * \param  Cachorros* this,char* nombre
 * \return int todoOk
 */
int cachorro_getNombre(Cachorros* this,char* nombre)
{
    int todoOk = 0;

    if( this != NULL && nombre != NULL)
    {
        strcpy(nombre, this->nombre);
        todoOk = 1;
    }
    return todoOk;
}


Cachorros* filtroMenores45Dias(Cachorros* this){


    int desde = 0;
    int hasta = 100;
    LinkedList* lista2 = NULL;



    if(this != NULL)
    {
        for(int i = 0; i< ll_len(this);i++){

            lista2 = ll_subList(this,desde,hasta);

        }
    }



    return lista2;
}


int filtroMachos(Cachorros* this){
    int todoOk = 0;


    return todoOk;
}
