#include <stdio.h>
#include <stdlib.h>
#include "LinkedList.h"
#include "cachorros.h"
#include <conio.h>
#include <string.h>

/** \brief Carga los datos de los empleados desde el archivo data.csv (modo texto).
 *
 * \param path char*
 * \param pArrayListEmployee LinkedList*
 * \return int
 *
 */
int controller_loadFromText(char* path, LinkedList* ArrayListCachorros)
{
    int todoOk = 0;
    FILE* f;
    char buffer[6][100];
    int cant;
    Cachorros* aux = NULL;

    if(path != NULL && ArrayListCachorros != NULL)
    {
        f = fopen(path, "r");

        if( f == NULL)
        {
            printf("No se pudo abrir el archivo\n");
            return todoOk;
        }
        fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2],buffer[3],buffer[4],buffer[5]);

        while(!feof(f))
        {
            cant = fscanf(f,"%[^,],%[^,],%[^,],%[^,],%[^,],%[^\n]\n", buffer[0], buffer[1], buffer[2],buffer[3],buffer[4],buffer[5]);
            if( cant == 6)
            {
                aux = cachorros_newParametros(buffer[0], buffer[1], buffer[2],buffer[3],buffer[4],buffer[5]);
                if( aux != NULL)
                {
                    ll_add(ArrayListCachorros,aux);
                }
            }
            else
            {
                break;
            }
        }

        todoOk = 1;
    }

    return todoOk;
}


int controller_ListCachorros(LinkedList* ArrayListCachorros)
{
    int todoOk = 0;
    Cachorros* aux;
    int flag = 0;
    if(ArrayListCachorros != NULL)
    {

        printf("  ID    NOMBRE      DIAS    RAZA    RESERVADO   GENERO  \n\n");
        for( int i=0; i < ll_len(ArrayListCachorros); i++)
        {
            aux = (Cachorros*) ll_get(ArrayListCachorros,i);
            mostrarCachorro(aux);
            flag = 1;
        }
        if(flag == 0)
        {
            printf("No hay empleados cargados para mostrar\n");
        }

        todoOk = 1;
    }
    return todoOk;
}


