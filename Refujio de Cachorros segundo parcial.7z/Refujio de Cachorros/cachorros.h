#ifndef CACHORROS_H_INCLUDED
#define CACHORROS_H_INCLUDED
typedef struct
{
    int id_Cachorro;
    char nombre[128];
    int dias;
    char raza[30];
    char reservado[2];
    char genero[1];

}Cachorros;

Cachorros* cachorros_new();
int mostrarCachorro(Cachorros* e);
Cachorros* cachorros_newParametros(char* idStr,char* nombreStr,char* diasStr,char* razaStr,char* reservadoStr,char* generoStr);
int cachorro_setId(Cachorros* this,int id);
int cachorro_setNombre(Cachorros* this,char* nombre);
int cachorro_setDias(Cachorros* this,int dias);
int cachorro_setRaza(Cachorros* this,char* raza);
int cachorro_setReservado(Cachorros* this,char* reservado);
int cachorro_setgenero(Cachorros* this,char* genero);
int cachorro_getNombre(Cachorros* this,char* nombre);

Cachorros* filtroMenores45Dias(Cachorros* this);
int filtroMachos(Cachorros* this);


#endif // CACHORROS_H_INCLUDED
