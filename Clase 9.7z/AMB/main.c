#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#define TAM 1

typedef struct{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct{
    int legajo;
    char nombre[20];
    int edad;
    char sexo;
    int nota1;
    int nota2;
    float promedio;
    eFecha fechaIngreso;

    int isEmpty;
}eAlumno;

void mostrarAlumno(eAlumno x);
void mostrarAlumnos(eAlumno vec[], int tam);
void ordenarAlumnos(eAlumno vec[], int tam);
int altaAlumno(eAlumno alumnos[],int tam);
void inicializacionAlumnos(eAlumno alumnos[], int tam);
int buscarLibre(eAlumno alumnos[], int tam);
int buscarAlumno(int legajo, eAlumno alumnos[], int tam);
eAlumno newAlumno(int legajo, char nombre[],char sexo, int edad, int n1, int n2, eFecha fecha);
int bajarAlumno(eAlumno alumnos[],int tam);
void modificarAlumno(eAlumno alumnos[],int tam);

int menuAlumno();
int menu();

int main()
{
    eAlumno lista[TAM];
    char seguir = 'n';

    inicializacionAlumnos(lista,TAM);

    do{

        switch(menu()){
            case 1:
                //printf("----- Alta de Alumnos -----");
                altaAlumno(lista, TAM);
                break;
            case 2:
                printf("----- Baja de Alumnos -----");
                bajarAlumno(lista,TAM);
                break;
            case 3:
                printf("----- Modificacion de Alumnos -----");
                modificarAlumno(lista,TAM);
                //aca va el alta alumno
                break;
            case 4:
                //printf("----- Listar Alumnos -----");
                mostrarAlumnos(lista, TAM);
                break;
            case 5:
                printf("----- Ordenar Alumnos -----");
                //aca va el alta alumno
                break;
            case 6:
                printf("----- Informes Alumnos -----");
                break;
            case 7:
                printf("Confirmar salida? ");
                fflush(stdin);
                seguir = getch();
                break;
            default :
                printf("Opcion Invalida");
                break;
        }

    }while(seguir == 'n');

    return 0;
}

void mostrarAlumno(eAlumno x){
    printf(" %d%10s    %d    %c      %d     %d      %.2f   %02d/%02d/%d\n",
           x.legajo,
           x.nombre,
           x.edad,
           x.sexo,
           x.nota1,
           x.nota2,
           x.promedio,
           x.fechaIngreso.dia,
           x.fechaIngreso.mes,
           x.fechaIngreso.anio);
}

void mostrarAlumnos(eAlumno vec[], int tam)
{
    int flag = 0;
    printf("Legajo   Nombre   Edad  Sexo  Nota1 Nota2 Promedio FIngreso\n");
        for(int i=0; i < tam; i++){
            if(vec[i].isEmpty == 0){
                mostrarAlumno(vec[i]);
                system("pause");
                flag = 1;
            }
        }

        if(flag == 0){
            system("cls");
            printf("\nNo hay Alumnos que mostrar.");
        }
    printf("\n\n");
}

void ordenarAlumnos(eAlumno vec[], int tam){

    eAlumno auxAlumno;

    for(int i= 0; i < tam-1 ; i++){
        for(int j= i+1; j <tam; j++){
            if( vec[i].legajo > vec[j].legajo){
                auxAlumno = vec[i];
                vec[i] = vec[j];
                vec[j] = auxAlumno;
            }
        }
    }
}

int menu(){

int opcion;

    system("cls");
    printf("Menu de Opciones \n\n");
    printf("1- Alta Alumno\n");
    printf("2- Baja Alumno\n");
    printf("3- Modificar Alumno\n");
    printf("4- Listar Alumno\n");
    printf("5- Ordenar Alumno\n");
    printf("6- Informes\n");
    printf("7- Salir\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

return opcion;
}


void inicializacionAlumnos(eAlumno alumnos[], int tam){
    for(int i=0; i < tam ; i ++){
        alumnos[i].isEmpty = 1;
    }
}

int buscarLibre(eAlumno alumnos[], int tam){
    int indice = -1;

    for(int i = 0; i < tam;i++){
        if(alumnos[i].isEmpty == 1){
            indice = i ;
            break;
        }
    }
    return indice;
}

int buscarAlumno(int legajo, eAlumno alumnos[], int tam){
    int indice = -1;

    for(int i = 0; i < tam;i++){
        if(alumnos[i].isEmpty == 0 && alumnos[i].legajo == legajo){
            indice = i ;
            break;
        }
    }
    return indice;
}

int altaAlumno(eAlumno alumnos[],int tam){
    int todoOk = 0;
    int indice;
    int esta;
    int legajo;
    int edad;
    int n1;
    int n2;
    char sexo;
    char nombre[20];
    //float promedio;
    eFecha fecha;
    //eAlumno nuevoAlumno;

    indice = buscarLibre(alumnos, tam);

    if(indice == -1){
        printf("Sistema Completo. No se pueden agregar mas alumnos\n");
        system("pause");
    }
    else{
        printf("Ingrese Legajo: ");
        scanf("%d",&legajo);
        esta = buscarAlumno(legajo,alumnos,tam);

        if(esta != -1){
            printf("Legajo ya registrado\n");
            mostrarAlumno(alumnos[esta]);

            system("pause");
        }
        else{
            printf("Ingrese Nombre: ");
            fflush(stdin);
            gets(nombre);

            printf("Ingrese edad: ");
            scanf("%d", &edad);

            printf("Ingrese sexo: ");
            fflush(stdin);
            scanf("%c", &sexo);

            printf("Ingrese nota parcial 1: ");
            scanf("%d", &n1);

            printf("Ingrese nota parcial 2: ");
            scanf("%d", &n2);

            printf("Ingrese fecha ingreso: dd/mm/aaaa ");
            scanf("%d/%d/%d", &fecha.dia, &fecha.mes, &fecha.anio);

            alumnos[indice] =  newAlumno(legajo, nombre, sexo, edad, n1, n2,fecha);
        }
    }
    return todoOk;
}

eAlumno newAlumno(int legajo, char nombre[],char sexo, int edad, int n1, int n2, eFecha fecha){
    eAlumno nuevoAlumno;
    nuevoAlumno.legajo = legajo;
    strcpy(nuevoAlumno.nombre, nombre);
    nuevoAlumno.edad = edad;
    nuevoAlumno.sexo = sexo;
    nuevoAlumno.nota1 = n1;
    nuevoAlumno.nota2 = n2;
    nuevoAlumno.promedio = (float) (n1 + n2) / 2;
    nuevoAlumno.fechaIngreso = fecha;

    nuevoAlumno.isEmpty = 0 ;
    return nuevoAlumno;
}


int bajarAlumno(eAlumno alumnos[],int tam){

    int todoOka = 0;
    int indice;
    int legajo;
    char confirma;

    system("cls");
    printf("\n----- Baja Alumno -----\n");
    printf("Ingrese Legajo : ");
    scanf("%d", &legajo);

    indice = buscarAlumno(legajo, alumnos,tam);


    if(indice == -1){
        printf("\nNo tenemos registrado ese legajo\n");
        system("pause");
    }
    else{
        mostrarAlumno(alumnos[indice]);
        printf("\nConfirma Eliminacion?: ");
        fflush(stdin);
        confirma = getche();
        if(confirma == 's'){
            alumnos[indice].isEmpty = 1;
            printf("\nSe ha Eliminado el Alumno\n");
            todoOka = 1;
        }
        else{

            printf("\nSe ha cancelado la baja.\n");
        }
        system("pause");
    }
    return todoOka;
}

void modificarAlumno(eAlumno alumnos[],int tam){
    int indice;
    int legajo;
    //char confirma;

    system("cls");
    printf("\n----- Modificacion Alumno -----\n");
    printf("Ingrese Legajo : ");
    scanf("%d", &legajo);

    indice = buscarAlumno(legajo, alumnos,tam);

    if(indice == -1){
        printf("\nNo tenemos registrado ese legajo\n");
        system("pause");
    }
    else{
        mostrarAlumno(alumnos[indice]);
        switch(menuAlumno()){
        case 1:
            system("pause");
            break;
        case 2:
            system("pause");
            break;
        case 3:
            system("pause");
            break;
        case 4:
            system("pause");
            break;
        case 5:
            system("pause");
            break;
        case 6:
            system("pause");
            break;
        case 7:
            printf("Confirmar salida? ");
            fflush(stdin);
            system("pause");
            break;
        default :
            printf("Opcion Invalida");
            break;
        }

        system("pause");
    }
}

int menuAlumno(){
    int opcion;
    system("cls");
    printf("Modificacion de Alumno \n\n");
    printf("1- Nombre\n");
    printf("2- Edad\n");
    printf("3- Sexo\n");
    printf("4- Nota 1\n");
    printf("5- Nota 2\n");
    printf("7- Cancelar\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}
