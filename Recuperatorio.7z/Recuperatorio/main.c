#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/**Desarrollar 3 funciones: la primera recibir� un array de n�meros enteros y le pedir� al usuario que ingrese
 10 n�meros, que no podr�n estar repetidos.
En caso de que el usuario intente ingresar 3 n�meros repetidos la funci�n devolver� un valor que represente un error.
 La segunda funci�n recibir� el array del punto anterior y devolver� la suma de los n�meros pares.
La ultima ordenar� el array de enteros de manera creciente y mostrar� el array ordenado.*/

int funcio1(int array[]);
int funcion2(int array[]);
int funcion3(int array[]);

int main()
{
    int numeros[10];
    int todoBien;
    int suma;
    printf("----- Funcio 1 -----\n\n");
    todoBien = funcio1(numeros);

    if(todoBien == 1){
        printf("ERROR. No se puede repetir el mismo Numero 3 veces.");
    }

    if(todoBien == 0){
        printf("\n----- Funcio 2 -----\n\n");
        suma =funcion2(numeros);
        printf("La suma total es de %d",suma);
    }
    printf("\n----- Funcio 3 -----\n\n");
    if(todoBien == 0){

    }
    return 0;
}

/** \brief Desarrollar 3 funciones: la primera recibir� un array de n�meros enteros y le pedir� al usuario que ingrese
    10 n�meros, que no podr�n estar repetidos.
    En caso de que el usuario intente ingresar 3 n�meros repetidos la funci�n devolver� un valor que represente un error.
 * \param int array[]
 * \return return 0 (todo bien) , 1 (ERROR).
 */
int funcio1(int array[]){
    int todoOk = 0;
    int aux = 0;
    int cant = 1;

    for(int i= 0; i<10;i++){
        printf("Ingrese un Numero: ");
        scanf("%d",&array[i]);


        if(aux == array[i]){
            printf("Error. El numero ya se encuentra cargado\n");
            aux = array[i];

            cant++;
        }

        if(cant == 3){
            todoOk = 1;
            return todoOk;
        }

        aux = array[i];
    }

    return todoOk;
}

/** \brief La segunda funci�n recibir� el array del punto anterior y devolver� la suma de los n�meros pares.
 * \param
 * \return retorna Int la suma total de los numeros pares;
 */

int funcion2(int array[]){
    int suma = 0;

    for(int i= 0; i<10;i++){
        if((array[i] / 2) == 0){
            suma = suma + array[i];
        }
    }

    return suma;
}

/** \brief La ultima ordenar� el array de enteros de manera creciente y mostrar� el array ordenado.
 * \param
 * \return
 */

/*
int funcio3(int array[]){
    //int aux[10];
    for(int i= 0; i<10;i++){
        if((array[i] / 2) == 0){

        }
    }
}
*/
