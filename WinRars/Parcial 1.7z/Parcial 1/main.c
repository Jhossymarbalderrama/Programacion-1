#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#define TAMMARCA 5
#define TAMCOLOR 5
#define TAMLAVADO 4
#define TAMAUTO 2

typedef struct
{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct
{
    int id; /**< comienza con 1000 */
    char decripcion[20];
}eMarca;

typedef struct
{
    int id;
    char nombreColor[20];
}eColor;

typedef struct
{
    int id;
    char patente[10];
    int autoMarca;
    int autoColor;
    int anio;/**< Anio de Fabrica */
    int isEmpty;
}eAuto;

typedef struct
{
    int id;/**< Comienza con 20000 */
    char descripcion[25];
    float precio;
}eServicio; /**< Lavados = Servicio */

typedef struct
{
    int id;/**< autoIncremental */
    char patente[10];/**< Validar */
    eServicio idServicio;
    eFecha fechaTrabajo;
}eTrabajo;


int menu();
void  altaAuto(eAuto autos[],int tam,eMarca marca[],int tamMarca,eColor color[],int tamColor);
eAuto newAuto(int id, char patente[], int idMarca, int idColor, int anio);
int verificarMarca(eMarca marca[],int tamMarca,int idMarca);
int  verificarColor(eColor color[],int tamColor,int idColor);
void mostrarAuto(eAuto x);
void mostrarAutos(eAuto autos[], int tam);
int bajaAutos(eAuto autos[], int tam);
int buscarAuto(int id, eAuto autos[], int tam);

int main()
{
    eMarca lista[TAMMARCA]=
    {
        { 1000,"Renault"},
        { 1001,"Fiat"},
        { 1002,"Ford"},
        { 1003,"Chevrolet"},
        { 1004,"Peugeot"}
    };

    eColor listaColor[TAMCOLOR]=
    {
        { 5000,"Negro"},
        { 5001,"Blanco"},
        { 5002,"Gris"},
        { 5003,"Rojo"},
        { 5004,"Azul"}
    };
    eServicio listaServicio[TAMLAVADO]=
    {
        { 2001,"Lavado",250.00},
        { 2002,"Pulido",300.00},
        { 2003,"Encerado",400.00},
        { 2004,"Completo",600.00}
    };
    eAuto listaAuto[TAMAUTO]=
    {
        { 1,"fal333",1000,5003,2005},
        { 2,"jlk",1001,5004,2010}

    };


    char salir = 'n';

    do
    {
        switch(menu())
        {
        case 1:
            altaAuto(listaAuto,TAMAUTO,lista,TAMMARCA,listaColor,TAMCOLOR);
            break;
        case 2:
            mostrarAutos(listaAuto,TAMAUTO);
            break;
        case 3:
            bajaAutos(listaAuto,TAMAUTO);
            break;
        case 4:
               printf("Listar Autos.");
               break;
        case 5:
               printf("Listar Marcas.");
               break;
        case 6:
            printf("\nConfirmar Salida? (S/N): ");
            fflush(stdin);
            salir = getchar();
            break;
        default:
            printf("Opcion invalida\n");
            fflush(stdin);
        }
        system("pause");
    }
    while(salir == 'n');

    return 0;
}


int menu()
{
    int opcion;
    system("cls");
    printf("***-- Sistema --***\n");
    printf("\n----- Menu de Opciones -----\n");
    printf("1- Alta de Auto.\n");
    printf("2- Modificar de Auto.\n");
    printf("3- Baja de Auto.\n");
    printf("4- Listar Autos.\n");
    printf("5- Listar Marcas.\n");
    printf("4- Salir.\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}


void  altaAuto(eAuto autos[],int tam,eMarca marca[],int tamMarca,eColor color[],int tamColor)
{
    int id;
    char patente[10];
    int idMarca;
    int idColor;
    int anio;
    int esta = 0;
    int estaColor = 0;


    system("cls");
    printf("----- Alta de Autos -----\n\n");

        printf("Ingrese id: ");
        scanf("%d",&id);

        printf("\nIngrese Patente: ");
        fflush(stdin);
        gets(patente);

        do{
            printf("\nIngrese ID Marca : ");
            scanf("%d",&idMarca);

            /**< Verificacion de Marca */
            esta = verificarMarca(marca,tamMarca,idMarca);
        }while(esta == 0);


        do{
            printf("\nIngrese ID Color: ");
            scanf("%d",&idColor);

            /**< Verificacion de Color */
            estaColor = verificarColor(color,tamColor,idColor);
        }while(estaColor == 0);

            printf("\nIngrese Modelo (ANIO): ");
            scanf("%d",&anio);

            newAuto(id, patente, idMarca, idColor, anio);

            printf("Alta Exitosa..");

}


eAuto newAuto(int id, char patente[], int idMarca, int idColor, int anio)
{
    eAuto newAuto;
    printf("%d",id);
    newAuto.id = id;
    strcpy(newAuto.patente,patente);
    newAuto.autoMarca = idMarca;
    printf("%d",id);
    newAuto.autoColor = idColor;
    newAuto.anio = anio;
    newAuto.isEmpty = 1;
}

int verificarMarca(eMarca marca[],int tamMarca,int idMarca){
    int flag = 0;

    for(int i = 0; i < tamMarca; i++){
        if(marca[i].id == idMarca){
            flag = 1;
        }
    }

    if(flag == 0){
           printf("La marco no se pudo encontrar");
    }

    return  flag;
}

int  verificarColor(eColor color[],int tamColor,int idColor){
    int flag = 0;

    for(int i = 0; i < tamColor; i++){
        if(color[i].id == idColor){
            flag = 1;
        }
    }

    if(flag == 0){
        printf("El Color no se pudo encontrar");
    }

    return  flag;
}


void mostrarAuto(eAuto x)
{
    printf(" %d     %s      %d      %d   %d \n\n",
           x.id,
           x.patente,
           x.autoMarca,
           x.autoColor,
           x.anio
          );
}

void mostrarAutos(eAuto autos[], int tam)
{
    int flag = 0;
    system("cls");
    printf("------- Lista de autos -------\n\n");

    printf(" ID          PATENTE       IdMARCA       IdCOLOR       MODELO \n\n");
    for(int i=0; i < tam; i++)
    {
        if(autos[i].isEmpty == 0)
        {
            mostrarAuto(autos[i]);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        system("cls");
        printf("\n---No hay autos que mostrar---");
    }

    //system("pause");
    printf("\n\n");
}

int bajaAutos(eAuto autos[], int tam)
{
    int todoOk = 0;
    int indice;
    int id;
    char confirma;

        system("cls");
        printf("----- Baja de Empleados -----\n\n");

        printf("Ingrese ID del Auto: ");
        scanf("%d", &id);

        indice = buscarAuto(id, autos, tam);

        if( indice == -1 )
        {
            printf("\nNo tenemos registrado ese ID\n");
            //system("pause");
        }
        else
        {
            mostrarAuto(autos[indice]);
            printf("\nConfirma eliminacion?: ");
            fflush(stdin);
            confirma = getche();
            if( confirma == 's')
            {
                autos[indice].isEmpty = 1;
                printf("\n\nSe ha eliminado al Empleado\n");
                todoOk = 1;
            }
            else
            {
                printf("\n\nSe ha cancelado la baja\n");
            }

        }
    return todoOk;
}

int buscarAuto(int id, eAuto autos[], int tam)
{
    int indice = -1;

    for(int i=0; i < tam; i++)
    {
        if( autos[i].isEmpty == 0 && autos[i].id == id)
        {
            indice = i;
            break;
        }
    }
    return indice;
}


int modificarEmpleado(eAuto autos[], int tam)
{
    int todoOk = 0;
    int indice;
    char exit = 'n';

    int color;
    int modelo;

        system("cls");
        printf("----- Modificacion de Empleado -----\n\n");

        printf("Ingrese ID del auto: ");
        scanf("%d", &indice);

        indice = buscarAuto(indice,autos,tam);

        if( indice == -1 )
        {
            printf("\nNo tenemos registrado ese legajo\n");
            //system("pause");
        }
        else
        {
            printf(" ID          PATENTE       IdMARCA       IdCOLOR       MODELO \n\n");
            mostrarAuto(autos[indice]);

            do
            {
                switch(menuModificar())
                {
                case 1:
                    printf("Ingrese Nuevo color: ");
                    scanf("%d",&color);

                    autos.autoColor = color;
                    break;
                case 2:
                    printf("Ingrese Nuevo Modelo: ");
                    scanf("%d",&modelo);

                    autos.anio = modelo;
                    break;
                case 3:
                    exit = getchar();
                    break;
                default:
                    printf("Opcion invalida\n");
                }
            }
            while(exit == 'n');
        }

    return todoOk;
}


int menuModificar()
{
    int opcion;
    printf("----- Que desea Modificar ? -----\n\n");
    printf("1- color.\n");
    printf("2- modelo.\n");
    printf("3- Volver a Menu Principal.\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);
    return opcion;

}
