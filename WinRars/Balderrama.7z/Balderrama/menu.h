#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#endif // MENU_H_INCLUDED

int menu();
