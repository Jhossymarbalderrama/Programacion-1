#ifndef AUTOS_H_INCLUDED
#define AUTOS_H_INCLUDED
#include "marca.h"
#include "color.h"

typedef struct{
    int id;
    char patente[20];
    int idMarca;
    int idColor;
    int modelo;
    int isEmpty;
    int idCliente;
}eAuto;

typedef struct{
    int id;
    char nombre[20];
    char Localidad[20];
    int isEmpty;
}eCliente;
#endif // AUTOS_H_INCLUDED

int hardcodearAutos( eAuto vec[], int tam, int cantidad);
void inicializarAutos(eAuto autos[], int tam);
void mostrarAuto(eAuto x, eMarca marcas[], int tam, eColor colores[],eCliente cliente[]);
void mostrarAutos (eAuto autos[], int tam,  eColor colores[], int tamColor, eMarca marcas[], int tamMarcas,eCliente cliente[]);
eAuto newAuto(int id,char patente[],int idMarca,int idColor,int modelo,int cliente);
int buscarLibre(eAuto vec[], int tam);

int altaAuto(eAuto autos[], int tam , eMarca marcas[], int tamMarcas, eColor colores[], int tamColores,eCliente cliente[],int tamCliente);
int buscarPatente(char patente[], eAuto autos[], int tam);
int modificarAuto(eAuto autos[], int tam,eColor colores[], int tamColores,eMarca marcas[],int tamMarcas,eCliente cliente[]);
int bajaAuto (eAuto autos[], int tam, eColor colores[], int tamColores,eMarca marcas[], int tamMarcas,eCliente cliente[]);
int buscarIdAuto(int id, eAuto autos[], int tam);
//Clientes
void mostrarClientes(eCliente cliente[],int tamCliente);
void  mostrarCliente(eCliente cliente);
int cargarDescCliente(int id, eCliente cliente[], int tam, char desc[]);
