#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include "fecha.h"
#include "autos.h"
#include "color.h"
#include "marca.h"
#include "servicios.h"
#include "trabajo.h"
#include "menu.h"


#define TAMAUTOS 10
#define TAMARCAS 5
#define TAMCOLOR 5
#define TAMSERVICIO 4
#define TAMTRABAJO 10
#define TAMCLIENTE 5

void menuInformes(eAuto autos[],int tamAutos,eMarca marcas[],int tamMarcas,eColor colores[],int tamColor,eServicio servicios[],int tamServicio,eTrabajo trabajos[],int tamTrabajo,eCliente cliente[]);
int menuInformesOpciones();
void mostrarAutosXMarca(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);
void mostrarAutosXColor(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);
void mostrarAutorXModelo(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);
void mostrarAutosXMarcaYModelo(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);
void mostrarAutosXMarcaYColor(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);

//Clientes
void mostrarClientes(eCliente cliente[],int tamCliente);
void mostrarCliente(eCliente cliente);

/**< Informe 2 */
void mostrarAutosNegros(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]);
void mostrarTrabajosporAuto(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],eTrabajo trabajos[],int tamTrabajo);

/**< Informe */

/**< Pedir Localidad - MOSTRAR LOS AUTOS DE ESA LOCALIDAD - Informe */
void mostrarAutosXLocalidad(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],int tamCliente);
/**< Elegir Titular -  Importe total de  los servicios Servicios */
void mostrarTotalTitular(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],int tamCliente,eTrabajo trabajos[],int tamTrabajo,eServicio servicios[],int tamServicio);



int main()
{
    int idAuto = 100;
    int idTrabajo = 60000;
    eMarca marcas[] = { {1000,"Renault"},{1001,"Fiat"}, {1002,"Ford"}, {1003,"Chevrolet"}, {1004,"Peugeot"}};
    eColor colores[] = {{5000,"Negro"},{5001,"Blanco"},{5002,"Gris"},{5003,"Rojo"},{5004,"Azul"}};
    eServicio servicios[] = {{20000,"Lavado",250},{20001,"Pulido",300},{20002,"Encerado",400},{20003,"Completo",600}};
    eCliente cliente[] = {{300,"Juan","quilmes",0},{301,"Maria","sarandi",0},{302,"Mario","wilde",0},{303,"Pepe","avellaneda",0},{304,"Lautaro","lanus",0}};
    eAuto vehiculos[TAMAUTOS];
    eTrabajo trabajos[TAMTRABAJO];

    inicializarAutos(vehiculos,TAMAUTOS);
    inicializarTrabajos(trabajos,TAMTRABAJO);

    idAuto = idAuto + hardcodearAutos(vehiculos,TAMAUTOS, 9);

    char respuesta = 'n';
    do
    {
        switch(menu())
        {
        case 1:
            altaAuto(vehiculos,TAMAUTOS,marcas,TAMARCAS,colores,TAMCOLOR,cliente,TAMCLIENTE);
            break;
        case 2:
            modificarAuto(vehiculos,TAMAUTOS,colores,TAMCOLOR,marcas,TAMARCAS,cliente);
            break;
        case 3:
            bajaAuto(vehiculos,TAMAUTOS,colores,TAMCOLOR,marcas,TAMARCAS,cliente);
            break;
        case 4:
            mostrarAutos(vehiculos,TAMAUTOS,colores,TAMCOLOR,marcas,TAMARCAS,cliente);
            break;
        case 5:
            mostrarMarcas(marcas,TAMARCAS);
            break;
        case 6:
            mostrarColores(colores,TAMCOLOR);
            break;
        case 7:
            mostrarServicios(servicios,TAMSERVICIO);
            break;
        case 8:
            if(altaTrabajo(trabajos,TAMTRABAJO,idTrabajo,vehiculos,TAMAUTOS,servicios,TAMSERVICIO,colores,TAMCOLOR,marcas,TAMARCAS,cliente))
            {
                idTrabajo++;
            }
            break;
        case 9:
            mostrarTrabajos(trabajos,TAMTRABAJO,servicios,TAMSERVICIO);
            break;
        case 10:
            menuInformes(vehiculos,TAMAUTOS,marcas,TAMARCAS,colores,TAMCOLOR,servicios,TAMSERVICIO,trabajos,TAMTRABAJO,cliente);
            break;
        case 11:
            mostrarClientes(cliente,TAMCLIENTE);
            break;
        case 12:
            mostrarAutosXLocalidad(vehiculos,TAMAUTOS,marcas,TAMARCAS,colores,TAMCOLOR,cliente,TAMCLIENTE);
            break;
        case 13:
            mostrarTotalTitular(vehiculos,TAMAUTOS,marcas,TAMARCAS,colores,TAMCOLOR,cliente,TAMCLIENTE,trabajos,TAMTRABAJO,servicios,TAMSERVICIO);
            break;
        case 20:
            printf("Confirma salir?:");
            fflush(stdin);
            respuesta = getche();
            printf("\n\n");
            break;

        default:
            printf("\nOpcion Invalida!\n\n");

        }
        system("pause");
    }
    while(respuesta == 'n');

    return 0;
}


void menuInformes(eAuto autos[],int tamAutos,eMarca marcas[],int tamMarcas,eColor colores[],int tamColor,eServicio servicios[],int tamServicio,eTrabajo trabajos[],int tamTrabajo,eCliente cliente[]){

    char respuesta = 'n';

    do{

        switch(menuInformesOpciones()){
            case 1:
                mostrarAutosXMarca(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 2:
                mostrarAutosXColor(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 3:
                mostrarAutorXModelo(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 4:
                mostrarAutosXMarcaYModelo(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 5:
                mostrarAutosXMarcaYColor(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 6:
                mostrarAutosNegros(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente);
                break;
            case 7:
                mostrarTrabajosporAuto(autos,tamAutos,marcas,tamMarcas,colores,tamColor,cliente,trabajos,tamTrabajo);
                break;
            case 20:
                printf("Confirma salir?:");
                fflush(stdin);
                respuesta = getche();
                printf("\n\n");
            break;

            default:
                printf("\nOpcion Invalida!\n\n");
        }
        system("pause");
    }while(respuesta == 'n');
}

int menuInformesOpciones()
{
    int opcion;

    system("cls");
    printf("------- INFORMES -------\n\n");
    printf("1--Mostrar Autos de una Marca.\n\n");
    printf("2-Mostrar Autos de un Color.\n");
    printf("3-Mostrar Autos de un Modelo.\n");
    printf("4-Mostrar Autos por Marca y Modelo.\n");
    printf("5-Mostrar Autos por Marca y Color.\n\n");
    printf("6-Mostrar Autos Color Negro.\n");
    printf("7-Mostrar todos los trabajos efectuados al auto seleccionado\n");
    printf("\n20-Salir.\n\n");
    printf("Ingrese opcion: ");
    scanf("%d", &opcion);

    return opcion;
}

void mostrarAutosXMarca(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){
    int idMarca;
    int cont = 0;
    char nombreMarca[20];
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Marca -----\n");


    do{

    mostrarMarcas(marcas,tamMarcas);
    printf("\nIngrese ID de la Marca: ");
    scanf("%d",&idMarca);

    }while(idMarca < 1000 && idMarca > 1005);


    for(int i = 0; i < tamAuto; i++){
        if(autos[i].isEmpty == 0 && autos[i].idMarca == idMarca){
            cont++;
        }
    }

    for(int i = 0; i<tamMarcas; i++){
        if(marcas[i].id == idMarca){
            strcpy(nombreMarca,marcas[i].descripcion);
            printf("La cantidad de %s son : %d .",nombreMarca,cont);
            printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
            break;
        }
    }

        for(int i=0; i < tamAuto; i++)
    {
        if( autos[i].isEmpty == 0 && autos[i].idMarca == idMarca)
        {
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        printf("\nNo hay Autos que mostrar\n");
    }
}

void mostrarAutosXColor(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){
    int idColor;
    int cont = 0;
    char nombreColor[20];
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Color -----\n");


    do{

    mostrarColores(colores,tamColor);
    printf("\nIngrese ID de la Color: ");
    scanf("%d",&idColor);

    }while(idColor < 5000 && idColor > 5004);


    for(int i = 0; i < tamAuto; i++){
        if(autos[i].isEmpty == 0 && autos[i].idColor == idColor){
            cont++;
        }
    }

    for(int i = 0; i<tamColor; i++){
        if(colores[i].id == idColor){
            strcpy(nombreColor,colores[i].nombreColor);
            printf("La cantidad de %s son : %d .",nombreColor,cont);
            printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
            break;
        }
    }

        for(int i=0; i < tamAuto; i++)
    {
        if( autos[i].isEmpty == 0 && autos[i].idColor == idColor)
        {
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        printf("\nNo hay Autos que mostrar\n");
    }

}

void mostrarAutorXModelo(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){
    int modelo;
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Modelo -----\n");

    mostrarAutos(autos,tamAuto,colores,tamColor,marcas,tamMarcas,cliente);
    printf("\nIngrese el Modelo: ");
    scanf("%d",&modelo);

    printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
    for(int i = 0; i<tamAuto ; i++){
        if(autos[i].isEmpty == 0 && autos[i].modelo == modelo){
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    printf("\n");
    if(flag == 0){
        printf("No hay Autos con este anio de Modelo.\n");
    }
}

void mostrarAutosXMarcaYModelo(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){

    int idMarca;
    int modelo;
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Marca y Modelo -----\n");


    do{

    mostrarMarcas(marcas,tamMarcas);
    printf("\nIngrese ID de la Marca: ");
    scanf("%d",&idMarca);

    }while(idMarca < 1000 && idMarca > 1005);

    printf("\nIngrese el Modelo: ");
    scanf("%d",&modelo);

    printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
    for(int i = 0; i<tamAuto ; i++){
        if(autos[i].isEmpty == 0 && autos[i].idMarca == idMarca && autos[i].modelo == modelo){
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    printf("\n");
    if(flag == 0){
        printf("No hay Autos con este anio de Modelo.\n");
    }
}

void mostrarAutosXMarcaYColor(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){
    int idMarca;
    int idColor;
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Marca y Color -----\n");


    do{

    mostrarMarcas(marcas,tamMarcas);
    printf("\nIngrese ID de la Marca: ");
    scanf("%d",&idMarca);

    }while(idMarca < 1000 && idMarca > 1005);


    do{

    mostrarColores(colores,tamColor);
    printf("\nIngrese ID de la Color: ");
    scanf("%d",&idColor);

    }while(idColor < 5000 && idColor > 5004);

    printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
    for(int i = 0; i<tamAuto ; i++){
        if(autos[i].isEmpty == 0 && autos[i].idMarca == idMarca && autos[i].idColor == idColor){
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    printf("\n");
    if(flag == 0){
        printf("No hay Autos con este Color.\n");
    }


}


/**< Cliente */
/*
void mostrarClientes(eCliente cliente[],int tamCliente){
    system("cls");
    printf("***** Listado Clientes *****\n\n");

    printf(" IDCliente       Nombre   Localidad \n\n");
    for(int i=0; i < tamCliente; i++){
        mostrarCliente(cliente[i]);
    }
    printf("\n");
}

void  mostrarCliente(eCliente cliente){
    printf("  %d      %10s   %10s \n",cliente.id,cliente.nombre,cliente.Localidad);
}
*/

/**< Pedir Localidad - MOSTRAR LOS AUTOS DE ESA LOCALIDAD - Informe */
void mostrarAutosXLocalidad(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],int tamCliente){
    char localidad[20];
    int flag = 0;
    int flag2 = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos de una Localidad -----\n");

    do{
        mostrarClientes(cliente,tamCliente);
        printf("Ingrese una Localidad: ");
        fflush(stdin);
        scanf("%s",localidad);

        for(int i = 0;i < tamCliente; i++){
        if(cliente[i].isEmpty == 0 && (strcmp(cliente[i].Localidad,localidad)== 0)){
                flag2 = 1;
        }
        }

    }while(flag2 == 0);

    for(int i = 0;i < tamCliente; i++){
        if(cliente[i].isEmpty == 0 && (strcmp(cliente[i].Localidad,localidad)== 0)){
            for(int j = 0; j<tamAuto;j++){
                if(autos[j].isEmpty == 0 && autos[j].idCliente == cliente[i].id){
                     mostrarAuto(autos[j],marcas,tamAuto,colores,cliente);
                     flag = 1;
                }
            }
        }
    }
    if(flag == 0){
        printf("Error. No tenemos esa localidad o dato Invalido\n");
    }

}

/**< Elegir Titular -  Importe total de  los servicios Servicios */
void mostrarTotalTitular(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],int tamCliente,eTrabajo trabajos[],int tamTrabajo,eServicio servicios[],int tamServicio){
    int idCliente;
    int flag = 0;
    int flag2 = 0;
    float total = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Total por Titular -----\n");

    do{
        mostrarClientes(cliente,tamCliente);
        printf("Ingrese la ID del Cliente: ");
        scanf("%d",&idCliente);

        for(int i = 0;i < tamCliente; i++){
            if(cliente[i].isEmpty == 0 && cliente[i].id == idCliente){
                flag2 = 1;
            }
        }

    }while(flag2 == 0);

/**< titular IDCLiente >> Autos >> Trabajo */
    for(int i = 0 ; i < tamAuto ; i++){
        if(autos[i].isEmpty == 0 && autos[i].idCliente == idCliente){
            for(int j = 0 ; j < tamTrabajo ; j++){
                if(trabajos[j].isEmpty == 0 && (strcmp(trabajos[i].patente,autos[i].patente)== 0)){
                    flag = 1;
                    for(int k = 0; k < tamServicio ; k++){
                        if(servicios[k].id == trabajos[j].idServicio){
                            total = total + servicios[k].precio;
                        }
                    }
                }
            }
        }
    }

    if(flag == 0){
        printf("\nNo tenemos ni un servicio echo para este Cliente.\n");
    }else{
        printf("Su total es : %.2f",total);
    }
}

void mostrarAutosNegros(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[]){

    int cont = 0;
    char nombreColor[20];
    int flag = 0;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Autos Por Color Negro -----\n");

/*
    do{

    mostrarColores(colores,tamColor);
    printf("\nIngrese ID de la Color: ");
    scanf("%d",&idColor);

    }while(idColor < 5000 && idColor > 5004);


    for(int i = 0; i < tamAuto; i++){
        if(autos[i].isEmpty == 0 && autos[i].idColor == idColor){
            cont++;
        }
    }

    */
    for(int i = 0; i<tamColor; i++){
        if(colores[i].id == 5000){
            strcpy(nombreColor,colores[i].nombreColor);
            printf("La cantidad de %s son : %d .",nombreColor,cont);
            printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
            break;
        }
    }


        for(int i=0; i < tamAuto; i++)
    {
        if( autos[i].isEmpty == 0 && autos[i].idColor == 5000)
        {
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
            flag = 1;
        }
    }

    if( flag == 0)
    {
        printf("\nNo hay Autos que mostrar\n");
    }
}

void mostrarTrabajosporAuto(eAuto autos[],int tamAuto,eMarca marcas[], int tamMarcas,eColor colores[],int tamColor,eCliente cliente[],eTrabajo trabajos[],int tamTrabajo){
    int idAuto;

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Trabajos por Auto -----\n");

    printf("\n   ID       Patente        Marca    Color    Modelo  \n\n");
    for(int i = 0; i<tamAuto ; i++){
        if(autos[i].isEmpty == 0){
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
        }
    }

    printf("\n");

    printf("Ingrese la Id del Auto: ");
    scanf("%d",&idAuto);

    system("cls");
    printf("-------- INFORMES --------\n\n");
    printf("----- Trabajos por Auto -----\n");
    for(int i = 0; i<tamAuto ; i++){
        if(autos[i].isEmpty == 0 && autos[i].id == idAuto){
            mostrarAuto(autos[i],marcas,tamAuto,colores,cliente);
        }
    }



}




